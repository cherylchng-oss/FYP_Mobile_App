import 'package:flutter/material.dart';

// Import the new 2026 Owner pages we just built
import 'owner/owner_dashboard.dart';
import 'owner/owner_users_page.dart';
import 'owner/owner_cluster.dart';
import 'owner/owner_logs_page.dart';

// Global navigator key (kept to prevent errors if your other files reference it)
final GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class CamsApp extends StatelessWidget {
  const CamsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CAMS - Owner Sandbox',
      debugShowCheckedModeBanner: false,
      navigatorKey: appNavigatorKey,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF905C3E), // AdminColors.primary
        ),
      ),
      // 1. Force the app to bypass login and open the Dashboard immediately
      initialRoute: '/owner',
      
      // 2. Only register the specific routes we are testing right now
      routes: {
        '/owner': (context) => const OwnerDashboard(),
        '/owner-users': (context) => const OwnerUsersPage(),
        '/owner-cluster': (context) => const OwnerClusterPage(),
        '/owner-logs': (context) => const OwnerLogsPage(),
        
        // A placeholder for the Profile tab so the app doesn't crash when you tap it
        '/profile': (context) => Scaffold(
              backgroundColor: const Color(0xFFF8F5F2), // Cream
              appBar: AppBar(
                backgroundColor: const Color(0xFF2C1A0E), // DrawerBg
                title: const Text('Profile', style: TextStyle(color: Colors.white)),
                iconTheme: const IconThemeData(color: Colors.white),
              ),
              body: const Center(
                child: Text('Profile Page Placeholder'),
              ),
            ),
      },
    );
  }
}