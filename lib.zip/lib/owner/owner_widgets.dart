import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../shared/colors.dart'; 

class OwnerStatusBar extends StatelessWidget {
  const OwnerStatusBar({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).padding.top,
      color: AdminColors.cream, // Changed from dark to cream to blend with the page
    );
  }
}

class OwnerHeader extends StatelessWidget {
  final String title;
  final String? subtitle;
  final bool showBack;

  const OwnerHeader({super.key, required this.title, this.subtitle, this.showBack = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      child: Row(
        children: [
          if (showBack) ...[
            GestureDetector(
              onTap: () => Navigator.of(context).pop(),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(color: AdminColors.textPrimary.withOpacity(0.04), blurRadius: 16, offset: const Offset(0, 4))
                  ],
                ),
                child: const Icon(Icons.arrow_back_ios_new_rounded, color: AdminColors.textPrimary, size: 16),
              ),
            ),
            const SizedBox(width: 16),
          ],
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.outfit(color: AdminColors.textPrimary, fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: -0.8),
                ),
                if (subtitle != null) ...[
                  const SizedBox(height: 6),
                  Text(subtitle!, style: GoogleFonts.outfit(color: AdminColors.textMuted, fontSize: 14, fontWeight: FontWeight.w500)),
                ]
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class OwnerSectionHeader extends StatelessWidget {
  final String title;
  final int? count;
  const OwnerSectionHeader({super.key, required this.title, this.count});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
      child: Row(
        children: [
          Text(title, style: GoogleFonts.outfit(color: AdminColors.textPrimary, fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
          if (count != null) ...[
            const SizedBox(width: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AdminColors.primary.withOpacity(0.08), 
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(count.toString(), style: GoogleFonts.outfit(color: AdminColors.primary, fontSize: 12, fontWeight: FontWeight.w700)),
            ),
          ]
        ],
      ),
    );
  }
}

// The Bouncy wrapper from earlier, kept for interactions
class BouncyInteractiveCard extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const BouncyInteractiveCard({super.key, required this.child, required this.onTap});

  @override
  State<BouncyInteractiveCard> createState() => _BouncyInteractiveCardState();
}

class _BouncyInteractiveCardState extends State<BouncyInteractiveCard> {
  bool _isPressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) {
        setState(() => _isPressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _isPressed = false),
      child: AnimatedScale(
        scale: _isPressed ? 0.97 : 1.0, 
        duration: const Duration(milliseconds: 150),
        curve: Curves.easeOutCubic,
        child: widget.child,
      ),
    );
  }
}

// Additional minor widgets omitted for brevity (keep your Loading, EmptyState, etc from before)
class OwnerLoading extends StatelessWidget {
  const OwnerLoading({super.key});
  @override
  Widget build(BuildContext context) => const Center(child: CircularProgressIndicator(color: AdminColors.success));
}

class OwnerEmptyState extends StatelessWidget {
  final String message;
  const OwnerEmptyState({super.key, required this.message});
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(40.0),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox_rounded, size: 48, color: AdminColors.textMuted.withOpacity(0.3)),
            const SizedBox(height: 16),
            Text(message, style: GoogleFonts.outfit(color: AdminColors.textMuted, fontSize: 14, fontWeight: FontWeight.w500), textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}