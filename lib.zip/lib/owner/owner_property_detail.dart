import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../api.dart' as api;
import '../shared/colors.dart'; // Using your shared colors

import 'owner_widgets.dart';

class OwnerPropertyDetailPage extends StatefulWidget {
  final Map<String, dynamic> property;
  const OwnerPropertyDetailPage({super.key, required this.property});

  @override
  State<OwnerPropertyDetailPage> createState() => _OwnerPropertyDetailPageState();
}

class _OwnerPropertyDetailPageState extends State<OwnerPropertyDetailPage> {
  final _pageController = PageController();
  int _currentImage = 0;
  List<Map<String, dynamic>> _recentBookings = [];
  bool _loadingBookings = true;

  @override
  void initState() {
    super.initState();
    _loadRecentBookings();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _loadRecentBookings() async {
    try {
      final reservations = await api.fetchReservation();
      final propertyName = (widget.property['name'] ?? '').toString();
      final propId = (widget.property['id'] ?? '').toString();
      
      final matched = reservations.whereType<Map>().where((r) {
        final rPid = (r['propertyid'] ?? r['propertyId'] ?? '').toString();
        final rPname = (r['propertyname'] ?? r['propertyaddress'] ?? '').toString();
        return rPid == propId || rPname == propertyName;
      }).take(5).map((r) {
        return {
          'id': (r['reservationid'] ?? '').toString(),
          'guest': (r['customername'] ?? r['username'] ?? 'Guest').toString(),
          'checkin': (r['checkindatetime'] ?? r['checkIn'] ?? '').toString(),
          'checkout': (r['checkoutdatetime'] ?? r['checkOut'] ?? '').toString(),
          'price': r['totalprice'],
          'status': (r['reservationstatus'] ?? r['status'] ?? '').toString(),
        };
      }).toList();
      
      if (!mounted) return;
      setState(() {
        _recentBookings = List<Map<String, dynamic>>.from(matched);
        _loadingBookings = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loadingBookings = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.property;
    final images = (p['images'] as List?)?.cast<String>() ?? const <String>[];
    
    return Scaffold(
      backgroundColor: AdminColors.cream,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          _buildSliverGlassHeader(images, p),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 40),
              child: Column(
                children: [
                  const SizedBox(height: 16),
                  _buildBentoHero(p),
                  if ((p['description'] ?? '').toString().isNotEmpty) ...[
                    const OwnerSectionHeader(title: 'About Property'),
                    _buildTextCard((p['description'] ?? '').toString()),
                  ],
                  const OwnerSectionHeader(title: 'Created by'),
                  _buildCreatorCard((p['creator'] ?? '').toString(), (p['creatorRole'] ?? '').toString()),
                  OwnerSectionHeader(title: 'Recent Bookings', count: _recentBookings.length),
                  if (_loadingBookings)
                    const OwnerLoading()
                  else if (_recentBookings.isEmpty)
                    const OwnerEmptyState(message: 'No recent bookings')
                  else
                    ..._recentBookings.map((b) => _buildBookingTile(b)),
                  const SizedBox(height: 16),
                  const OwnerInfoBanner(),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _buildSliverGlassHeader(List<String> images, Map<String, dynamic> p) {
    return SliverAppBar(
      expandedHeight: 260,
      pinned: true,
      backgroundColor: AdminColors.drawerBg,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 20),
        onPressed: () => Navigator.pop(context),
      ),
      flexibleSpace: FlexibleSpaceBar(
        background: Stack(
          fit: StackFit.expand,
          children: [
            images.isNotEmpty
                ? PageView.builder(
                    controller: _pageController,
                    itemCount: images.length,
                    onPageChanged: (i) => setState(() => _currentImage = i),
                    itemBuilder: (_, i) => Image.network(images[i], fit: BoxFit.cover),
                  )
                : Container(color: AdminColors.primaryLight, child: const Icon(Icons.apartment, size: 60, color: Colors.white54)),
            Positioned(
              bottom: 0, left: 0, right: 0,
              height: 120,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, AdminColors.drawerBg]),
                ),
              ),
            ),
            if (images.length > 1)
              Positioned(
                bottom: 16, right: 16,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      color: Colors.black.withValues(alpha: 0.3),
                      child: Text('${_currentImage + 1} / ${images.length}', style: GoogleFonts.outfit(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildBentoHero(Map<String, dynamic> p) {
    final active = p['active'] == true;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AdminColors.cardBg,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AdminColors.border),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 15, offset: const Offset(0, 5))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(
                child: Text(
                  (p['name'] ?? '').toString(),
                  style: GoogleFonts.outfit(color: AdminColors.textPrimary, fontSize: 20, fontWeight: FontWeight.w800, letterSpacing: -0.5),
                ),
              ),
              OwnerStatusBadge(active: active), 
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              _buildBentoStat(Icons.bed_rounded, '${p['rooms'] ?? 0}', 'Rooms'),
              Container(width: 1, height: 30, color: AdminColors.border, margin: const EdgeInsets.symmetric(horizontal: 16)),
              _buildBentoStat(Icons.category_rounded, (p['type'] ?? 'N/A').toString(), 'Type'),
              if (p['rate'] != null) ...[
                Container(width: 1, height: 30, color: AdminColors.border, margin: const EdgeInsets.symmetric(horizontal: 16)),
                _buildBentoStat(Icons.attach_money_rounded, '${p['rate']}', 'Per Night', isHighlight: true),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBentoStat(IconData icon, String value, String label, {bool isHighlight = false}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, size: 14, color: isHighlight ? AdminColors.success : AdminColors.textMuted),
            const SizedBox(width: 4),
            Text(value, style: GoogleFonts.outfit(color: AdminColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w700)),
          ],
        ),
        Text(label, style: GoogleFonts.outfit(color: AdminColors.textMuted, fontSize: 11)),
      ],
    );
  }

  Widget _buildTextCard(String text) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: AdminColors.cardBg, borderRadius: BorderRadius.circular(16), border: Border.all(color: AdminColors.border)),
      child: Text(text, style: GoogleFonts.outfit(color: AdminColors.textMuted, fontSize: 13, height: 1.5)),
    );
  }

  Widget _buildCreatorCard(String name, String role) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: AdminColors.cardBg, borderRadius: BorderRadius.circular(16), border: Border.all(color: AdminColors.border)),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: AdminColors.primaryLight,
            radius: 20,
            child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?', style: GoogleFonts.outfit(color: Colors.white, fontWeight: FontWeight.w700)),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(name.isEmpty ? 'Unknown' : name, style: GoogleFonts.outfit(color: AdminColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w700)),
              Text(role, style: GoogleFonts.outfit(color: AdminColors.textMuted, fontSize: 11)),
            ],
          )
        ],
      ),
    );
  }

  Widget _buildBookingTile(Map<String, dynamic> booking) {
    final isActive = !(booking['status'] ?? '').toString().toLowerCase().contains('cancel');
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AdminColors.cardBg, borderRadius: BorderRadius.circular(16), border: Border.all(color: AdminColors.border)),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: isActive ? AdminColors.success.withValues(alpha: 0.15) : AdminColors.danger.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(12)),
            child: Icon(Icons.receipt_long_rounded, size: 16, color: isActive ? AdminColors.success : AdminColors.danger),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(booking['guest'].toString(), style: GoogleFonts.outfit(color: AdminColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text('Status: ${booking['status']}', style: GoogleFonts.outfit(color: AdminColors.textMuted, fontSize: 11)),
              ],
            ),
          ),
          Text('\$${booking['price'] ?? '-'}', style: GoogleFonts.outfit(color: AdminColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}