import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../api.dart' as api;
import '../shared/colors.dart'; // Using your shared colors

import 'owner_widgets.dart';
import 'owner_property_detail.dart';

class OwnerClusterDetailPage extends StatefulWidget {
  final Map<String, dynamic> cluster;
  const OwnerClusterDetailPage({super.key, required this.cluster});

  @override
  State<OwnerClusterDetailPage> createState() => _OwnerClusterDetailPageState();
}

class _OwnerClusterDetailPageState extends State<OwnerClusterDetailPage> {
  List<Map<String, dynamic>> _properties = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadProperties();
  }

  Future<void> _loadProperties() async {
    setState(() => _isLoading = true);
    try {
      final data = await api.fetchPropertiesListingTable();
      final List<dynamic> raw = (data['properties'] ?? data['data']) as List? ?? const [];
      final clusterName = (widget.cluster['name'] ?? '').toString();
      
      final filtered = raw.whereType<Map<String, dynamic>>().where((p) {
        return (p['clustername'] ?? p['cluster_name'] ?? '').toString() == clusterName;
      }).map((p) {
        final status = (p['propertystatus'] ?? p['status'] ?? 'Available').toString();
        List<String> images = [];
        final img = p['propertyimage'] ?? p['propertyImage'];
        if (img is List) images = img.map((e) => e.toString()).toList();
        else if (img is String && img.isNotEmpty) images = img.split(',').map((s) => s.trim()).toList();

        return {
          'id': (p['propertyid'] ?? p['propertyId'] ?? p['id'] ?? '').toString(),
          'name': (p['propertyaddress'] ?? p['propertydescription'] ?? 'Unnamed').toString(),
          'type': (p['propertytype'] ?? p['type'] ?? '').toString(),
          'rooms': (p['rooms'] ?? p['roomCount'] ?? p['room_count'] ?? 0),
          'status': status,
          'active': !status.toLowerCase().contains('inactive') && !status.toLowerCase().contains('suspended'),
          'rate': p['normalrate'],
          'description': (p['propertydescription'] ?? '').toString(),
          'nearby': (p['nearbylocation'] ?? '').toString(),
          'images': images,
          'creator': (p['username'] ?? '').toString(),
          'creatorRole': (p['usergroup'] ?? '').toString(),
        };
      }).toList();

      if (!mounted) return;
      setState(() {
        _properties = filtered;
        _isLoading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.cluster;
    final loc = [c['state'], c['province']].where((s) => s != null && s.toString().isNotEmpty).join(', ');

    return Scaffold(
      backgroundColor: AdminColors.cream,
      body: Column(
        children: [
          const OwnerStatusBar(),
          Container(
            color: AdminColors.drawerBg, // Dark header
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                OwnerHeader(
                  title: (c['name'] ?? 'Cluster').toString(),
                  showBack: true,
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
                  child: Row(
                    children: [
                      _GlassPill(icon: Icons.place_outlined, label: loc.isEmpty ? 'Sarawak' : loc),
                      const SizedBox(width: 8),
                      _GlassPill(
                        icon: Icons.apartment_rounded, 
                        label: '${_properties.length} Properties',
                        isHighlight: true,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          OwnerSectionHeader(title: 'Properties in Cluster', count: _properties.length),
          Expanded(
            child: _isLoading
                ? const OwnerLoading()
                : RefreshIndicator(
                    onRefresh: _loadProperties,
                    color: AdminColors.success,
                    child: _properties.isEmpty
                        ? ListView(children: const [OwnerEmptyState(message: 'No properties found here.')])
                        : ListView.builder(
                            padding: const EdgeInsets.only(top: 8, bottom: 40),
                            itemCount: _properties.length,
                            itemBuilder: (_, i) => _buildPropertyBentoCard(_properties[i]),
                          ),
                  ),
          ),
          const OwnerInfoBanner(),
        ],
      ),
    );
  }

  Widget _buildPropertyBentoCard(Map<String, dynamic> p) {
    final rooms = p['rooms'];
    final type = (p['type'] ?? '').toString();
    final isActive = p['active'] == true;
    final images = p['images'] as List<String>;

    return GestureDetector(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => OwnerPropertyDetailPage(property: p))),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: AdminColors.cardBg,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AdminColors.border),
          boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.03), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: Row(
          children: [
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                color: AdminColors.surface,
                borderRadius: BorderRadius.circular(14),
                image: images.isNotEmpty ? DecorationImage(image: NetworkImage(images.first), fit: BoxFit.cover) : null,
              ),
              child: images.isEmpty ? const Icon(Icons.apartment_rounded, color: AdminColors.textMuted) : null,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    (p['name'] ?? '').toString(),
                    style: GoogleFonts.outfit(color: AdminColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w700),
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    [if (rooms != null && rooms != 0) '$rooms rooms', if (type.isNotEmpty) type].join(' · '),
                    style: GoogleFonts.outfit(color: AdminColors.textMuted, fontSize: 12),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: isActive ? AdminColors.success.withValues(alpha: 0.15) : AdminColors.danger.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      isActive ? 'Active' : 'Inactive',
                      style: GoogleFonts.outfit(
                        color: isActive ? AdminColors.success : AdminColors.danger, 
                        fontSize: 10, fontWeight: FontWeight.w700
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right_rounded, color: AdminColors.textMuted, size: 20),
          ],
        ),
      ),
    );
  }
}

class _GlassPill extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isHighlight;

  const _GlassPill({required this.icon, required this.label, this.isHighlight = false});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: isHighlight ? AdminColors.success.withValues(alpha: 0.2) : Colors.white.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withValues(alpha: 0.15)),
          ),
          child: Row(
            children: [
              Icon(icon, color: isHighlight ? Colors.lightGreenAccent : Colors.white, size: 12),
              const SizedBox(width: 6),
              Text(
                label,
                style: GoogleFonts.outfit(color: isHighlight ? Colors.lightGreenAccent : Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}