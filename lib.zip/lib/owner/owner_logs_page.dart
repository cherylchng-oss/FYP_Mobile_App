import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../shared/colors.dart';
import '../shared/bottom_navigation_bar.dart';
import '../shared/navigation_menu.dart' as nav;

import 'owner_widgets.dart';

class OwnerLogsPage extends StatefulWidget {
  const OwnerLogsPage({super.key});

  @override
  State<OwnerLogsPage> createState() => _OwnerLogsPageState();
}

class _OwnerLogsPageState extends State<OwnerLogsPage> {
  int _tabIndex = 0; // 0 = Book & Pay, 1 = Audit Trails
  bool _isLoading = true;
  final TextEditingController _searchController = TextEditingController();

  // Mock Data
  final List<Map<String, dynamic>> _bookLogs = [
    {'action': 'New Booking Created', 'type': 'Booking', 'user': 'Alex Smith', 'time': 'Today, 10:45 AM'},
    {'action': 'Payment Successful - \$250', 'type': 'Payment', 'user': 'Sarah Connor', 'time': 'Today, 09:12 AM'},
    {'action': 'Booking Cancelled', 'type': 'Cancel', 'user': 'John Doe', 'time': 'Yesterday, 14:30 PM'},
  ];

  final List<Map<String, dynamic>> _auditLogs = [
    {'action': 'Updated Property Rate', 'type': 'Other', 'user': 'AdminUser', 'time': 'Today, 11:00 AM'},
    {'action': 'Suspended Customer', 'type': 'Cancel', 'user': 'ModTeam', 'time': 'Yesterday, 16:20 PM'},
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    await Future.delayed(const Duration(milliseconds: 600));
    if (mounted) setState(() => _isLoading = false);
  }

  void _onNavTap(int index) {
    if (index == 3) return;
    switch (index) {
      case 0: Navigator.of(context).pushReplacementNamed('/owner'); break;
      case 1: Navigator.of(context).pushReplacementNamed('/owner-users'); break;
      case 2: Navigator.of(context).pushReplacementNamed('/owner-cluster'); break;
      case 4: Navigator.of(context).pushNamed('/profile'); break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final displayList = _tabIndex == 0 ? _bookLogs : _auditLogs;

    return Scaffold(
      backgroundColor: AdminColors.cream,
      body: Column(
        children: [
          const OwnerStatusBar(),
          const OwnerHeader(title: 'Logs & Audit', subtitle: 'Platform activity overview'),
          _buildSegmentedToggle(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 8.0),
            child: _buildAestheticSearchBar(),
          ),
          OwnerSectionHeader(title: 'Recent Entries', count: displayList.length),
          Expanded(
            child: _isLoading
                ? const OwnerLoading()
                : ListView.builder(
                    padding: const EdgeInsets.only(top: 8, bottom: 100),
                    itemCount: displayList.length,
                    itemBuilder: (_, i) => _buildLogCard(displayList[i], i),
                  ),
          ),
        ],
      ),
      bottomNavigationBar: SharedBottomNavigationBar(
        selectedIndex: 3,
        onTap: _onNavTap,
        role: nav.UserRole.owner,
      ),
    );
  }

  Widget _buildSegmentedToggle() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 16),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(color: Colors.black.withOpacity(0.04), borderRadius: BorderRadius.circular(20)),
      child: Row(
        children: [
          Expanded(child: _buildTogglePill('Book & Pay', 0)),
          Expanded(child: _buildTogglePill('Audit Trails', 1)),
        ],
      ),
    );
  }

  Widget _buildTogglePill(String title, int index) {
    final isActive = _tabIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _tabIndex = index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isActive ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          boxShadow: isActive ? [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 2))] : [],
        ),
        alignment: Alignment.center,
        child: Text(
          title,
          style: GoogleFonts.outfit(color: isActive ? AdminColors.textPrimary : AdminColors.textMuted, fontSize: 14, fontWeight: isActive ? FontWeight.w700 : FontWeight.w500),
        ),
      ),
    );
  }

  Widget _buildAestheticSearchBar() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [BoxShadow(color: AdminColors.textPrimary.withOpacity(0.04), blurRadius: 24, offset: const Offset(0, 8))],
      ),
      child: TextField(
        controller: _searchController,
        decoration: InputDecoration(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          hintText: 'Search logs...',
          hintStyle: GoogleFonts.outfit(color: AdminColors.textMuted.withOpacity(0.6), fontSize: 15),
          prefixIcon: Padding(padding: const EdgeInsets.only(left: 16, right: 12), child: Icon(Icons.search_rounded, color: AdminColors.textMuted.withOpacity(0.6), size: 22)),
          prefixIconConstraints: const BoxConstraints(minWidth: 40),
        ),
      ),
    );
  }

  Widget _buildLogCard(Map<String, dynamic> log, int index) {
    final type = log['type'].toString();
    Color badgeBg = AdminColors.border;
    Color badgeText = AdminColors.textMuted;
    
    if (type == 'Booking') { badgeBg = AdminColors.success.withOpacity(0.15); badgeText = AdminColors.success; }
    if (type == 'Payment') { badgeBg = AdminColors.warning.withOpacity(0.15); badgeText = AdminColors.warning; }
    if (type == 'Cancel')  { badgeBg = AdminColors.danger.withOpacity(0.15);  badgeText = AdminColors.danger; }

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 300 + (index * 100).clamp(0, 400)),
      curve: Curves.easeOutQuart,
      builder: (context, value, child) => Transform.translate(offset: Offset(0, 20 * (1 - value)), child: Opacity(opacity: value, child: child)),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.black.withOpacity(0.02), width: 1),
          boxShadow: [BoxShadow(color: AdminColors.textPrimary.withOpacity(0.02), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: Text(log['action'], style: GoogleFonts.outfit(color: AdminColors.textPrimary, fontSize: 15, fontWeight: FontWeight.w700, height: 1.3))),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(color: badgeBg, borderRadius: BorderRadius.circular(12)),
                  child: Text(type, style: GoogleFonts.outfit(color: badgeText, fontSize: 10, fontWeight: FontWeight.w700)),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Icon(Icons.person_outline_rounded, size: 14, color: AdminColors.textMuted),
                const SizedBox(width: 4),
                Text(log['user'], style: GoogleFonts.outfit(color: AdminColors.textMuted, fontSize: 12)),
                const SizedBox(width: 12),
                Icon(Icons.access_time_rounded, size: 14, color: AdminColors.textMuted),
                const SizedBox(width: 4),
                Text(log['time'], style: GoogleFonts.outfit(color: AdminColors.textMuted, fontSize: 12)),
              ],
            )
          ],
        ),
      ),
    );
  }
}