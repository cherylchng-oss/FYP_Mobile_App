import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../shared/colors.dart';
import '../shared/bottom_navigation_bar.dart';
import '../shared/navigation_menu.dart' as nav;

import 'owner_widgets.dart';

class OwnerUsersPage extends StatefulWidget {
  const OwnerUsersPage({super.key});

  @override
  State<OwnerUsersPage> createState() => _OwnerUsersPageState();
}

class _OwnerUsersPageState extends State<OwnerUsersPage> {
  int _tabIndex = 0; // 0 = Customers, 1 = Staff
  bool _isLoading = true;
  final TextEditingController _searchController = TextEditingController();

  // Mock Data
  final List<Map<String, dynamic>> _customers = [
    {'name': 'Alex Johnson', 'email': 'alex@example.com', 'role': 'Customer', 'active': true},
    {'name': 'Sarah Smith', 'email': 'sarah@example.com', 'role': 'Customer', 'active': true},
    {'name': 'Mike Ross', 'email': 'mike@example.com', 'role': 'Customer', 'active': false},
  ];
  
  final List<Map<String, dynamic>> _staff = [
    {'name': 'Admin User', 'email': 'admin@hellosarawak.com', 'role': 'Admin', 'active': true},
    {'name': 'Mod Team', 'email': 'mod@hellosarawak.com', 'role': 'Moderator', 'active': true},
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    await Future.delayed(const Duration(milliseconds: 600));
    if (mounted) setState(() => _isLoading = false);
  }

  void _onNavTap(int index) {
    if (index == 1) return;
    switch (index) {
      case 0: Navigator.of(context).pushReplacementNamed('/owner'); break;
      case 2: Navigator.of(context).pushReplacementNamed('/owner-cluster'); break;
      case 3: Navigator.of(context).pushReplacementNamed('/owner-logs'); break;
      case 4: Navigator.of(context).pushNamed('/profile'); break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final displayList = _tabIndex == 0 ? _customers : _staff;

    return Scaffold(
      backgroundColor: AdminColors.cream,
      body: Column(
        children: [
          const OwnerStatusBar(),
          const OwnerHeader(title: 'Users', subtitle: 'Manage all platform users'),
          _buildSegmentedToggle(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 8.0),
            child: _buildAestheticSearchBar(),
          ),
          OwnerSectionHeader(title: _tabIndex == 0 ? 'All Customers' : 'All Staff', count: displayList.length),
          Expanded(
            child: _isLoading
                ? const OwnerLoading()
                : ListView.builder(
                    padding: const EdgeInsets.only(top: 8, bottom: 100),
                    itemCount: displayList.length,
                    itemBuilder: (_, i) => _buildUserCard(displayList[i], i),
                  ),
          ),
        ],
      ),
      bottomNavigationBar: SharedBottomNavigationBar(
        selectedIndex: 1,
        onTap: _onNavTap,
        role: nav.UserRole.owner,
      ),
    );
  }

  Widget _buildSegmentedToggle() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 16),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.04),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Expanded(child: _buildTogglePill('Customers', 0)),
          Expanded(child: _buildTogglePill('Admin / Mod', 1)),
        ],
      ),
    );
  }

  Widget _buildTogglePill(String title, int index) {
    final isActive = _tabIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _tabIndex = index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: isActive ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          boxShadow: isActive ? [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 2))] : [],
        ),
        alignment: Alignment.center,
        child: Text(
          title,
          style: GoogleFonts.outfit(
            color: isActive ? AdminColors.textPrimary : AdminColors.textMuted,
            fontSize: 14,
            fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildAestheticSearchBar() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [BoxShadow(color: AdminColors.textPrimary.withOpacity(0.04), blurRadius: 24, offset: const Offset(0, 8))],
      ),
      child: TextField(
        controller: _searchController,
        decoration: InputDecoration(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(24), borderSide: BorderSide.none),
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          hintText: 'Search users...',
          hintStyle: GoogleFonts.outfit(color: AdminColors.textMuted.withOpacity(0.6), fontSize: 15),
          prefixIcon: Padding(padding: const EdgeInsets.only(left: 16, right: 12), child: Icon(Icons.search_rounded, color: AdminColors.textMuted.withOpacity(0.6), size: 22)),
          prefixIconConstraints: const BoxConstraints(minWidth: 40),
        ),
      ),
    );
  }

  Widget _buildUserCard(Map<String, dynamic> u, int index) {
    final role = u['role'].toString();
    final isActive = u['active'] == true;
    Color avatarColor = AdminColors.primaryLight;
    if (role.toLowerCase() == 'admin') avatarColor = AdminColors.success;
    if (role.toLowerCase() == 'moderator') avatarColor = AdminColors.warning;

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 300 + (index * 100).clamp(0, 400)),
      curve: Curves.easeOutQuart,
      builder: (context, value, child) => Transform.translate(offset: Offset(0, 20 * (1 - value)), child: Opacity(opacity: value, child: child)),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 6),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.black.withOpacity(0.02), width: 1),
          boxShadow: [BoxShadow(color: AdminColors.textPrimary.withOpacity(0.03), blurRadius: 16, offset: const Offset(0, 6))],
        ),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: avatarColor.withOpacity(0.15),
              radius: 24,
              child: Text(u['name'][0], style: GoogleFonts.outfit(color: avatarColor, fontSize: 16, fontWeight: FontWeight.w800)),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(u['name'], style: GoogleFonts.outfit(color: AdminColors.textPrimary, fontSize: 16, fontWeight: FontWeight.w700)),
                  Text(u['email'], style: GoogleFonts.outfit(color: AdminColors.textMuted, fontSize: 13)),
                ],
              ),
            ),
            OwnerStatusBadge(active: isActive),
          ],
        ),
      ),
    );
  }
}