import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../shared/colors.dart';
import '../shared/bottom_navigation_bar.dart';
import '../shared/navigation_menu.dart' as nav;

import 'owner_widgets.dart';

class OwnerDashboard extends StatefulWidget {
  const OwnerDashboard({super.key});

  @override
  State<OwnerDashboard> createState() => _OwnerDashboardState();
}

class _OwnerDashboardState extends State<OwnerDashboard> {
  bool _isLoading = true;
  String _selectedPeriod = 'This month';

  // Mock data for the dashboard
  final double _totalRevenue = 12450.00;
  final int _totalUsers = 142;
  final int _totalProperties = 34;
  final int _totalReservations = 89;
  final double _guestRating = 4.8;
  final int _totalClusters = 6;

  @override
  void initState() {
    super.initState();
    _loadDashboard();
  }

  Future<void> _loadDashboard() async {
    await Future.delayed(const Duration(milliseconds: 800));
    if (mounted) setState(() => _isLoading = false);
  }

  void _onNavTap(int index) {
    if (index == 0) return;
    switch (index) {
      case 1: Navigator.of(context).pushReplacementNamed('/owner-users'); break;
      case 2: Navigator.of(context).pushReplacementNamed('/owner-cluster'); break;
      case 3: Navigator.of(context).pushReplacementNamed('/owner-logs'); break;
      case 4: Navigator.of(context).pushNamed('/profile'); break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AdminColors.cream,
      body: Column(
        children: [
          const OwnerStatusBar(),
          const OwnerHeader(title: 'Owner Panel', subtitle: 'Good morning, Admin'),
          Expanded(
            child: _isLoading
                ? const OwnerLoading()
                : RefreshIndicator(
                    onRefresh: _loadDashboard,
                    color: AdminColors.success,
                    backgroundColor: AdminColors.cardBg,
                    child: ListView(
                      padding: const EdgeInsets.only(bottom: 40),
                      children: [
                        _buildHeroRevenueCard(),
                        const Padding(
                          padding: EdgeInsets.fromLTRB(20, 24, 20, 12),
                          child: Text('Overview', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AdminColors.textPrimary)),
                        ),
                        _buildBentoGrid(),
                      ],
                    ),
                  ),
          ),
        ],
      ),
      bottomNavigationBar: SharedBottomNavigationBar(
        selectedIndex: 0,
        onTap: _onNavTap,
        role: nav.UserRole.owner,
      ),
    );
  }

  Widget _buildHeroRevenueCard() {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: const Duration(milliseconds: 600),
      curve: Curves.easeOutQuart,
      builder: (context, value, child) => Transform.translate(offset: Offset(0, 20 * (1 - value)), child: Opacity(opacity: value, child: child)),
      child: Container(
        margin: const EdgeInsets.fromLTRB(20, 16, 20, 0),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AdminColors.drawerBg, // Deep espresso hero
          borderRadius: BorderRadius.circular(28),
          boxShadow: [BoxShadow(color: AdminColors.drawerBg.withOpacity(0.3), blurRadius: 24, offset: const Offset(0, 12))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('TOTAL REVENUE', style: GoogleFonts.outfit(color: Colors.white.withOpacity(0.6), fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1.2)),
                _buildGlassPeriodSelector(),
              ],
            ),
            const SizedBox(height: 16),
            TweenAnimationBuilder<double>(
              tween: Tween(begin: 0, end: _totalRevenue),
              duration: const Duration(milliseconds: 1500),
              curve: Curves.easeOutExpo,
              builder: (context, value, child) {
                return Text('\$${value.toStringAsFixed(2)}', style: GoogleFonts.outfit(color: Colors.white, fontSize: 40, fontWeight: FontWeight.w800, letterSpacing: -1.5));
              },
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: AdminColors.success.withOpacity(0.2),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: AdminColors.success.withOpacity(0.3)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.trending_up_rounded, color: Colors.lightGreenAccent, size: 14),
                  const SizedBox(width: 6),
                  Text('12.5% from last month', style: GoogleFonts.outfit(color: Colors.lightGreenAccent, fontSize: 12, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGlassPeriodSelector() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          color: Colors.white.withOpacity(0.1),
          child: Row(
            children: [
              Text(_selectedPeriod, style: GoogleFonts.outfit(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w500)),
              const SizedBox(width: 4),
              const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white70, size: 14),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBentoGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: GridView.count(
        crossAxisCount: 2,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        childAspectRatio: 1.1,
        children: [
          _buildStatCard('Users', _totalUsers.toString(), Icons.people_rounded, AdminColors.primaryLight, isPositive: true, index: 1),
          _buildStatCard('Properties', _totalProperties.toString(), Icons.apartment_rounded, AdminColors.success, index: 2),
          _buildStatCard('Reservations', _totalReservations.toString(), Icons.calendar_today_rounded, AdminColors.primaryLight, index: 3),
          _buildStatCard('Guest Rating', '$_guestRating', Icons.star_rounded, AdminColors.success, suffix: '/ 5.0', index: 4),
          _buildStatCard('Clusters', _totalClusters.toString(), Icons.location_city_rounded, AdminColors.primaryLight, index: 5),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color iconBg, {bool isPositive = false, String? suffix, required int index}) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 400 + (index * 100)),
      curve: Curves.easeOutQuart,
      builder: (context, val, child) => Transform.translate(offset: Offset(0, 20 * (1 - val)), child: Opacity(opacity: val, child: child)),
      child: BouncyInteractiveCard(
        onTap: () {}, // Make interactive if needed
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.black.withOpacity(0.02), width: 1),
            boxShadow: [BoxShadow(color: AdminColors.textPrimary.withOpacity(0.04), blurRadius: 20, offset: const Offset(0, 8))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: iconBg.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
                    child: Icon(icon, color: iconBg, size: 20),
                  ),
                  if (isPositive) const Icon(Icons.arrow_upward_rounded, color: AdminColors.success, size: 18),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: GoogleFonts.outfit(color: AdminColors.textMuted, fontSize: 13, fontWeight: FontWeight.w500)),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(value, style: GoogleFonts.outfit(color: AdminColors.textPrimary, fontSize: 24, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                      if (suffix != null)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 4, left: 4),
                          child: Text(suffix, style: GoogleFonts.outfit(color: AdminColors.textMuted, fontSize: 12, fontWeight: FontWeight.w600)),
                        ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}